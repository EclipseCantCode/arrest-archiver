ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.PrintName		= "Arrest DB"
ENT.Author			= "Eclipse"
ENT.Contact			= "Talk to the dev team"
ENT.Purpose			= "Use arrest database"
ENT.Category        = "Eclipse"
ENT.Spawnable       = true
 